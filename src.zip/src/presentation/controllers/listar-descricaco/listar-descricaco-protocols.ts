export * from "../../../domain/models/descricaco";
export * from "../../../domain/usecases/add-descricaco";
export * from "../../protocols";
