export * from "../../../domain/models/atestado-aprovado";
export * from "../../../domain/usecases/add-atestatdo-aprovado";
export * from "../../protocols";
