export * from "../../../domain/models/get-funcionário";
export * from "../../../domain/usecases/get-funcionario";
export * from "../../protocols";
