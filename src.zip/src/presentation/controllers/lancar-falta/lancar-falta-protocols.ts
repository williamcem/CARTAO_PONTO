export * from "../../../domain/models/lancar-falta";
export * from "../../../domain/usecases/lancar-falta";
export * from "../../protocols";
