export * from "../../../domain/models/tipos-acompanhante";
export * from "../../../domain/usecases/tipos-acompanhantes";
export * from "../../protocols";
