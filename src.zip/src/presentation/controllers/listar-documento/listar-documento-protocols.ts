export * from "../../../domain/models/tipos-documento";
export * from "../../../domain/usecases/tipos-documento";
export * from "../../protocols";
