export * from "../../../domain/models/descricacao";
export * from "../../../domain/usecases/add-descricacao";
export * from "../../protocols";
