export * from "../../../domain/models/atestado";
export * from "../../../domain/usecases/add-atestado";
export * from "../../protocols";
