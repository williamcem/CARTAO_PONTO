export interface EventosDocumentosModel {
  data: Date;
  tipoId: string;
  identificacao: string;
  minutos: number;
}
