export interface AtestadoRecusadoModel {
  id: number;
  inicio: Date;
  fim: Date;
  statusId: number;
  observacao: string;
}
