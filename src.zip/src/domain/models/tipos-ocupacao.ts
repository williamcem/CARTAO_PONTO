export interface OcupacaoModel {
  nome: string;
}
