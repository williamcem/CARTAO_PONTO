export interface DescricacoModel {
  descricaco: string;
}
