export interface StatusLnacamentoModel {
  nome: string;
}
