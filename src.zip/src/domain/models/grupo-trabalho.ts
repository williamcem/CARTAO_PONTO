export interface GrupoTrabalhoModel {
  saved: boolean;
}
