export interface DeleteCartoaModel {
  referencia: string;
}
