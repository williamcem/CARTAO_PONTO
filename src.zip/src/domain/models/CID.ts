export interface ListarAtestadosModel {
  id: string;
}
