export interface StatusDocumentoModel {
  nome: string;
}
