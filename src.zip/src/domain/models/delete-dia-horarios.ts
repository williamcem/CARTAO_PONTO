export interface DeleteModel {
  cartao_dia_id: number;
}
