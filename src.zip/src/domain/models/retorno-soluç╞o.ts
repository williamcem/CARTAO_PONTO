export interface RetornoSolucaoModel {
  cartaoDiaId: number;
}
