export interface EventosModel {
  data: Date;
  tipoId: string;
  identificacao: string;
  minutos: number;
}
