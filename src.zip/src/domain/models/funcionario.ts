export interface FuncionarioUpsertModel {
  saved: boolean;
}
