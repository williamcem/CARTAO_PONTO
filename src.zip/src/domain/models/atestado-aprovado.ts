export interface AtestadoAprovadoModel {
  id: number;
  inicio: Date;
  fim: Date;
  statusId: number;
}
