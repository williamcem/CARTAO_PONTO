export interface ListarFilialModel {
  nome: string;
  identificação: string;
  id: number;
  filial: string;
}
