export interface TiposDocumentosModel {
  nome: string;
}
