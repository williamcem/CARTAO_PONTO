export interface ExpotacaoDemitidosModel {
  identificao: number;
  localidade: string;
}
