export interface SoluçãoEventoModel {
  data: Date;
  tipoId: string;
  identificacao: string;
  minutos: number;
}
