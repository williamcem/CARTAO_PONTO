export interface LancamentoDiaModel {
  entrada: Date;
  saida: Date;
  periodo: number;
  id: number;
  userName: string;
}
