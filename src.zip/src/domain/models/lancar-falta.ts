export interface LancarFaltaModel {
  periodoId: number;
  cartao_dia_id: number;
  statusId: number;
  userName: string;
}
