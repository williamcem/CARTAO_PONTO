export interface AcompanhanteModel {
  nome: string;
}
