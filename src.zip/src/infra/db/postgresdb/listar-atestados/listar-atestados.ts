import { PrismaClient } from "@prisma/client";

import { ListarAtestado } from "../../../../data/usecase/add-listar-atestados/add-listar-atestados";
import { prisma } from "../../../database/Prisma";

export class ListarAtestadoRepsository implements ListarAtestado {
  private prisma: PrismaClient;

  constructor() {
    this.prisma = prisma;
  }

  public async list(): Promise<any[]> {
    const atestados = await this.prisma.atestado_funcionario.findMany({
      where: {
        tipo_status: {
          id: 1,
        },
      },
      include: {
        funcionario: true,
        tipo_acompanhante: true,
        tipo_ocupacao: true,
        tipo_status: true,
        tipos_documentos: true,
      },
    });

    return atestados.map((atestado) => ({
      id: atestado.id,
      inicio: atestado.inicio,
      fim: atestado.fim,
      grupo_cid: atestado.grupo_cid,
      acidente_trabalho: atestado.acidente_trabalho,
      tipoAcompanhanteId: atestado.tipoAcompanhanteId,
      descricao: atestado.descricao,
      userName: atestado.userName,
      funcionarioId: atestado.funcionarioId,
      tipoId: atestado.tipoId,
      statusId: atestado.statusId,
      idade_paciente: atestado.idade_paciente,
      ocupacaoId: atestado.ocupacaoId,
      eventosId: atestado.eventosId,
      funcionario: {
        nome: atestado.funcionario?.nome,
        identificacao: atestado.funcionario?.identificacao,
        nomeAcompanhante: atestado.tipo_acompanhante?.nome,
        nomeOcupacao: atestado.tipo_ocupacao?.nome,
        nomeStatus: atestado.tipo_status?.nome,
        nomeDocumento: atestado.tipos_documentos?.nome,
      },
    }));
  }
}
