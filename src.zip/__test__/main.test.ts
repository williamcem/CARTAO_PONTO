import { expect, test } from "vitest";

test("Hello World", () => {
  expect("Hello World").toBe("Hello World");
});
